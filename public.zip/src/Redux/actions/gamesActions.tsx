import React from 'react'

import axios from 'axios';

import {Dispatch} from 'redux'
import { ActionType } from '../actionTypes/actionTypesEnum';
import {Actions} from '../actionTypes/gamesActionTypes'

export const getGames = () => async (dispatch:Dispatch<Actions>) => {

    
      dispatch({ type: ActionType.GET_ALLGAMES });
    try {
      
  
      const { data } = await axios.get("/game/");
  
      dispatch({
        type: ActionType.GET_ALLGAMES_SUCCESS,
        payload: data,
      });
    } catch (error) {
      dispatch({
        type: ActionType.GET_ALLGAMES_FAIL,
        
      });
    }
  };

  export const getGamesBytime = () => async (dispatch:Dispatch<Actions>) => {

    
    dispatch({ type: ActionType.GET_ALLGAMESBYTIME });
  try {
    

    const { data } = await axios.get("/game/select_top_by_playtime");

    dispatch({
      type: ActionType.GET_ALLGAMESBYTIME_SUCCESS,
      payload: data,
    });
  } catch (error) {
    dispatch({
      type: ActionType.GET_ALLGAMESBYTIME_FAIL,
      
    });
  }
};

export const getGamesByPlayers = () => async (dispatch:Dispatch<Actions>) => {

    
  dispatch({ type: ActionType.GET_ALLGAMESBYPLAYERS });
try {
  

  const { data } = await axios.get("/game/select_top_by_players");

  dispatch({
    type: ActionType.GET_ALLGAMESBYPLAYERS_SUCCESS,
    payload: data,
  });
} catch (error) {
  dispatch({
    type: ActionType.GET_ALLGAMESBYPLAYERS_FAIL,
    
  });
}
};
