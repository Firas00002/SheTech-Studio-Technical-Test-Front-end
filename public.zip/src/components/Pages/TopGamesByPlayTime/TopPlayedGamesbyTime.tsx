import { useDispatch, useSelector } from "react-redux";
import { bindActionCreators } from "redux";
import { ActionsCreator } from "../../../Redux";
import { StateType } from "../../../Redux/reducers/Reducer";
import { useEffect} from "react";

import { Col, Row } from "react-bootstrap";
import { TopPlayedGamesByPlaytimeCard } from "./TopPlayedGamesplayersCard";


export function TopPlayedGamesbyTime(){



  const dispatch = useDispatch();
  const {getGamesBytime} =bindActionCreators(ActionsCreator,dispatch)
   
   const {
    topgamesbytime 
   } = useSelector((state:Partial<StateType>) => state);
   useEffect(() => {
    getGamesBytime()
   }, [])

return <>



<Row md={4} xs={2} sm={2}>
        {topgamesbytime  && topgamesbytime .map((item:any) =>(
         < Col>
         
         <TopPlayedGamesByPlaytimeCard  {...item} />
        </Col>  ))}
        
      </Row>
</>


    
    
}