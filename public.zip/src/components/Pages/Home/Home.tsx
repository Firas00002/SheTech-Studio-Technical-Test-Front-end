
import './home.css'
export function Home() {
  return (
      
    <div className='body'>

    </div>

  )
}
