



import React from 'react'
import { Col, Row } from 'react-bootstrap';
import { StateType } from '../../../Redux/reducers/Reducer';
import { useDispatch, useSelector } from 'react-redux';
import { bindActionCreators } from 'redux';
import { ActionsCreator } from '../../../Redux';
import {useEffect} from 'react'
import TopPlayedGamesByPlayersCard from './TopPlayedGamesplayersCard';
const TopPlayedGamesByPlayers = () => {

  const dispatch = useDispatch();
  const {getGamesByPlayers} =bindActionCreators(ActionsCreator,dispatch)
   
   const {
    topgamesbyplayers
   } = useSelector((state:Partial<StateType>) => state);
   useEffect(() => {
    getGamesByPlayers()
   }, [])
  return (
    <>
    <Row md={4} xs={2} sm={2}>
        {topgamesbyplayers  && topgamesbyplayers .map((item:any) =>(
         < Col>
         
         <TopPlayedGamesByPlayersCard  {...item} />
        </Col>  ))}
        
      </Row></>
  )
}

export default TopPlayedGamesByPlayers